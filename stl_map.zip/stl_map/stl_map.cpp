﻿// stl_map.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include <iostream>
#include <map>
using namespace std;

int main()
{
    std::cout << "Hello lets create a map<int, int> this time\n";
    std::cout << "you have to enter your choice , here is the menu :\n";
    std::cout << "0. Exit\n";
    std::cout << "1. insert\n";
    std::cout << " 2. emplace \n";
    std::cout << "  3. at\n";
    std::cout << " 4. contains\n";
    std::cout << " 5. count\n";
    std::cout << " 6. print\n";
    std::cout << " 7. size\n";
    std::cout << " 8. empty\n";
    std::cout << " 9. erase\n";
    std::cout << " 10. clear \n";
    
    std::map<int, int> mp;
  
    int exit = 1;
    int key = 0, i = 0, val = 0;
    while (exit)
    {
        std::cout << "Enter choice of operation to be done\n";
        int choice;
        std::cin >> choice;
        switch (choice)
        {
        case 0:
            exit = 0;
            break;
        case 1:
            cout << "Enter key and value  to add";
            cin >> key;
            cin >> val;
            mp.insert({ key,val });
            break;
        case 2:
            cout << "Enter key and val to emplace";
            cin >> key;
            cin >> val;
            mp.emplace(key, val);
            break;
        case 3:

            cout << "Enter key to look at";
            cin >> i;
            cout << "val is "<< mp.at(i) <<endl;

            break;
        case 4:
            cout << "Enter key to search";
            cin >> key;
            if (mp.end() != mp.find(key))
            {
                cout << " yes it conatins this key";
            }
            else
            {
                cout << "No it does not conatin this key";
            }
            break;
        case 5:
            cout << "Enter key";
            cin >> key;
            
            {
                cout << "Count of key is " << mp.count(key);
            }
            break;
        case 6:
            cout << "here is display of this map" << endl;
            for (auto it : mp)
            {
                cout << "key is : "<< it.first << "value is" << it.second << endl;
            }
            cout << "end of display" << endl;
            break;
        case 7:
            cout << "size of map is" << endl;
            cout << mp.size() << endl;
           
            break;
        case 8:
            if (mp.empty()) {
                cout << "map is empty";
            }
            cout << "map is not empty";
            break;
        case 9:
            cout << "key to erase";
            cin >> key;
            mp.erase(key);
            break;
        case 10:
            mp.clear();
            break;
           
        
        }
    }

}
/*
Perfect! Here's a clean list of method names you can implement in your custom `MapWrapper` class (to simulate STL `std::map` behavior):

---

### ✅ **Core Functionalities**

1. `void insert(int key, const std::string& value)`
2. `void emplace(int key, const std::string& value)`
3. `std::string& at(int key)`
4. `std::string& operator[](int key)`
5. `bool contains(int key)`
6. `int count(int key)`
7. `void erase(int key)`
8. `void clear()`
9. `size_t size() const`
10. `bool empty() const`
11. `void print() const`

---

### ✅ **Iterator / Traversal**

12. `void print_in_order() const`
13. `void print_reverse_order() const`

---

### ✅ **Find / Bounds**

14. `bool find(int key)`
15. `std::pair<int, std::string> lower_bound(int key)`
16. `std::pair<int, std::string> upper_bound(int key)`

---

### ✅ **Comparisons / Utilities**

17. `bool equals(const MapWrapper& other) const`
18. `void swap(MapWrapper& other)`

---

Would you also like to add:

* ✅ `begin()` / `end()` wrapper functions for iteration?
* ✅ Support for **custom comparators**?

Let me know if you're ready for testing tasks too.
*/

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
