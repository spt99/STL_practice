// stl_vector.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "vector"
#include "algorithm"
using namespace std;

int main()
{
    int exit = 1;
    int choice;
    vector<int> vec;
    int m = 0;
    int elem = 0, idx = 0;
    std::cout << "Hello User.. lets make dynamic array and do operation on it!\n";
    std::cout << "1. Add element\n2. Insert at index\n 3. Delete by index\n 4. Search for element\n 5. Update element \n 6. Display vector \n 7. Show size & capacity\n8. Sort\n9. Reverse\n10. Clear vector\n0. Exit\nEnter your choice";
    while (exit)
    {
        cout << "Enter your choice" << endl;
        std::cin >> choice;
        switch (choice)
        {
        case 0:
            exit = 0;
            break;
        case 1:
           
            cout << "Enter element to add";
            cin >> elem;
            vec.push_back(elem);
            break;
        case 2:
           
            cout << "Enter element to insert";
            cin >> elem;
            cout << "Enter index to insert at";
            cin >> idx;
            vec[idx] = elem;
            break;
        case 3:
            
            cout << "Enter index to delete at";
            cin >> idx;
            vec.erase(vec.begin()+ idx);
            
            break;
        case 4:
            
            cout << "Enter elem to search at";
            cin >> elem;
            for (auto itr : vec)
            {
                if (vec[itr] == elem)
                {
                    cout << "elem is present at itr " << itr << std::endl;
                    break;
                }
            }
            break;
        case 5:
            cout << "Enter element";
            cin >> elem;
            cout << "Enter idx";
            cin >> idx;
            vec[idx] = elem;
            break;
        case 6:
            cout << "here is display of this vector"<<endl;
            for (auto it: vec)
            {
                cout <<   it << endl;
            }
            cout << "end of display" << endl;
            break;
        case 7:
            cout<<"size of vector is"<< endl;
            cout<< vec.size()<<endl;
            cout << "capacity of vector is" << endl;
            cout<< vec.capacity()<<endl;
            break;
        case 8:
            std::sort(vec.begin(), vec.end());
            cout << "here is display of sorted vector" << endl;
            for (auto it2 : vec)
            {
                cout << it2 << endl;
            }
            cout << "end of display of sorted vector" << endl;
            break;
        case 9:
            m = vec.size() - 1;
            for (int i = 0;i< vec.size()/2;i++)
            {
                int temp = vec[i];
                vec[i] = vec[m];
                vec[m] = temp;
                m--;
            }
            cout << "here is display of reversed vector" << endl;
            for (auto it3 : vec)
            {
                cout << it3 << endl;
            }
            cout << "end of display of reversed vector" << endl;
            break;
        case 10:
            vec.clear();
            break;
        }
    }
    
    return 0;
       
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
