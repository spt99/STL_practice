// stl_list.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <list>
using namespace std;
/*
empty	Test whether container is empty (public member function)
size	Return size (public member function)
max_size	Return maximum size (public member function)

Element access:
front	Access first element (public member function)
back	Access last element (public member function)

Modifiers:
assign	Assign new content to container (public member function)
emplace_front	Construct and insert element at beginning (public member function)
push_front	Insert element at beginning (public member function)
pop_front	Delete first element (public member function)
emplace_back	Construct and insert element at the end (public member function)
push_back	Add element at the end (public member function)
pop_back	Delete last element (public member function)
emplace	Construct and insert element (public member function)
insert	Insert elements (public member function)
erase	Erase elements (public member function)
swap	Swap content (public member function)
resize	Change size (public member function)
clear	Clear content (public member function)

Operations:
splice	Transfer elements from list to list (public member function)
remove	Remove elements with specific value (public member function)
remove_if	Remove elements fulfilling condition (public member function template)
unique	Remove duplicate values (public member function)
merge	Merge sorted lists (public member function)
sort	Sort elements in container (public member function)
reverse	Reverse the order of elements (public member function)*/

int main()
{
    std::cout << "Hello lets create a list (doubly linked list) this time\n";
    std::cout << "you have to enter your choice , here is the menu :\n";
    std::cout << "0. Exit\n";
    std::cout << "1. assign\n";
    std::cout << " 2. front \n";
    std::cout << "  3. back\n";
    std::cout << " 4. emplace_front\n";
    std::cout << " 5. push_front\n";
    std::cout << " 6. pop_back\n";
    std::cout << " 7. size\n";
    std::cout << " 8. empty\n";
    std::cout << " 9. erase\n";
    std::cout << " 10. clear \n";
    std::cout << "11. emplace\n";
    std::cout << "12. reverse\n";
    std::cout << "13.remove\n";
    std::cout << "14.remove_if\n";
    std::cout << "15. unique\n";
    std::cout << "16.sort\n";
    std::cout << "17. merge\n";
    std::cout << "18.insert\n";

    list<int> ls;
    auto it = ls.begin();
    int exit = 1;
    int i = 0, val = 0;
    while (exit)
    {
        std::cout << "Enter choice of operation to be done\n";
        int choice;
        std::cin >> choice;
        switch (choice)
        {
        case 0:
            exit = 0;
            break;
        case 1:
            cout << "Enter elem to add\n";
            cin >> val;
            cout << "Enter idx to assign to\n";
            cin >> i;
            ls.assign(val,i);
            break;
        case 2:
            
            cout << "Here is Front elem  : "<< ls.front();
            break;
        case 3:

            cout << "here is elem at back of list" << ls.back();

            break;
        case 4:
            cout << "Enter val to emplace front";
            cin >> val;
            ls.emplace_front(val);
            break;
        case 5:
            cout << "Enter val to push front";
            cin >> val;
            ls.push_front(val);
            break;
        case 6:
            cout << "back elem is poped";
            ls.pop_back();
            break;
        case 7:
            cout << "size of list is" << endl;
            cout << ls.size() << endl;

            break;
        case 8:
            if (ls.empty()) {
                cout << "list is empty";
            }
            cout << "list is not empty";
            break;
        case 9:
           
            cout << "enter index to erase at";
            cin >> i;
            it = ls.begin();
            std::advance(it, i);
            ls.erase(it);
            break;
        case 10:
            /*emplace \n";
    std::cout << "11. clear\n";
    std::cout << "12. reverse\n";
    std::cout << "13.remove\n";
    std::cout << "14.remove_if\n";
    std::cout << "15. unique\n";
    std::cout << "16.sort\n";
    std::cout << "17. print\n";
    std::cout << "18.insert\n";*/
            ls.clear();
            break;
        case 11:
            std::cout << "enter val to emplace\n";
            cin >> val;
            std::cout << " enter index to emplace at\n";
            cin >> i;
            it = ls.begin();
            std::advance(it, i);
            //std::list<int> :: const_iterator it = ls.begin() + i;
            ls.emplace(it, val);
            break;
        case 12:
            ls.reverse();
            break;
        case 13:
            cout << "enter val to remove \n";
            cin >> val;
            ls.remove(val);
            break;
        case 14:
            
            ls.erase(std::remove_if(ls.begin(), ls.end(), [](int x) { return x % 2 == 0; }), ls.end());

            break;
        case 15:
            ls.unique();
            break;
        case 16:
            ls.sort();
        case 17:
            for (auto itr : ls)
            {
                cout << itr;
                itr++;
            }
            break;
        case 18:
            cout << "enter element to insert \n";
            cin >> val;
            ls.insert(ls.end(), val);
            break;
        }
    }


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
